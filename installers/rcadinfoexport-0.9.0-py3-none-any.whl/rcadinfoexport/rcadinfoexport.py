import ldap3 as ld

###Funtion to Make Connection to AD/LDAP server###
def ad_connection(ServerNameorIP,BindAccount,BindPass):
    ###Import Modules Needed for Function###
    import ldap3 as ld
    ########
    DomainController = ld.Server(ServerNameorIP)
    BindAccount = BindAccount
    BindPass = BindPass
    DCConnection = ld.Connection(DomainController,BindAccount,BindPass,auto_bind=True)
    return DCConnection
################

###Function to Get Info from AD/LDAP###  
###Store the Info in a Dataframe########
def ad_info_export(DCConnection,SearchBase,ADAttributes,SearchScope=ld.SUBTREE,SearchFilter='(objectclass=person)'):
    ###Import Modules Needed for Function###
    import ldap3 as ld
    import pandas as pd
    import ast
    ########

    ###Function Variables###
    ADRecords = []
    df_ADRecords = pd.DataFrame()
    ########

    ###Pull AD Records###
    if type(SearchBase) == str: #single OU
        ADRecords = list(DCConnection.extend.standard.paged_search(
            SearchBase,search_scope=SearchScope,search_filter=SearchFilter,attributes=ADAttributes))
    elif type(SearchBase) == tuple: #multiple OUs
        for Base in SearchBase:
            ADRecords += list(DCConnection.extend.standard.paged_search(
                Base,search_scope=SearchScope,search_filter=SearchFilter,attributes=ADAttributes))
    ########

    ###Extract Info into Dataframe##
    for entry in ADRecords:
        ldapAttributes = entry['raw_attributes']
        strAttributes = str(ldapAttributes)
        dictAttributes = ast.literal_eval(strAttributes)
        df_temp = pd.DataFrame.from_dict(dictAttributes, orient='index')
        df_temp = df_temp.transpose()
        df_ADRecords = pd.concat([df_ADRecords,df_temp])
    ########

    ###Cleanup and Format Data###
    columns_names = list(df_ADRecords)
    df_ADRecords[columns_names] = df_ADRecords[columns_names].astype(str)
    for col in columns_names:
        df_ADRecords[col] =  df_ADRecords[col].str.lstrip("b")
        df_ADRecords[col] = df_ADRecords[col].str.strip("'")
    df_ADRecords.reset_index(drop=True, inplace=True)
    df_ADRecords.replace('None','',inplace=True)
    df_ADRecords = df_ADRecords.applymap(lambda x: x.replace('"', ''))
    return df_ADRecords
    ########
################