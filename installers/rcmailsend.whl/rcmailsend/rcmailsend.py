def mail_send(receipientEmail,subject,messageAttachment='',
    senderEmail='scriptmaster@redclay.k12.de.us',
    smtpServer='smtp.k12.de.us',
    messageBody='The script has completed.'):
    ###Function Modules###
    import sys
    import smtplib
    import os
    from email import encoders
    from email.mime.base import MIMEBase
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    ########

    ###Function Variables###
    mailServer = smtplib.SMTP(smtpServer)
    message = message = MIMEMultipart()
    message = MIMEMultipart()
    message["From"] = senderEmail
    message["To"] = receipientEmail
    message["Subject"] = subject
    message.attach(MIMEText(messageBody, "plain"))
    ########

    ###Add Attachement to Message if Present###
    if messageAttachment != '':
        #Open Attachment for Processing
        with open(messageAttachment, "rb") as attachment:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())
        #Encode Attachment for Message
        encoders.encode_base64(part)
        #Add Attachment, Displaying Only the File Name (not full path)
        part.add_header("Content-Disposition","attachment", filename=os.path.basename(messageAttachment))
        message.attach(part)
    ########

    ###Convert Message for Transit###
    text = message.as_string()
    ########

    ###Send Message###
    mailServer.sendmail(senderEmail, receipientEmail, text)
    ########